<?php
/**
 *
 * @ingroup Language
 * @file
 */

$rtl = true;
