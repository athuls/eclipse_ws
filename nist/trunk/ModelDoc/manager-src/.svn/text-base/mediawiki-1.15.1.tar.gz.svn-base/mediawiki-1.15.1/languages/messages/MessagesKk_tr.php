<?php
/** Kazakh (Turkey) (‪Qazaqşa (Türkïya)‬)
 *
 * @ingroup Language
 * @file
 *
 */

# Inherit everything for now
$fallback = 'kk-latn';
