<?php
/** Min Nan (Bân-lâm-gú/閩南話)
 *
 * @ingroup Language
 * @file
 *
 */

# Inherit everything for now
$fallback = 'nan';
