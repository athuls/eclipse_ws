ALTER TABLE "text" RENAME TO pagecontent;
