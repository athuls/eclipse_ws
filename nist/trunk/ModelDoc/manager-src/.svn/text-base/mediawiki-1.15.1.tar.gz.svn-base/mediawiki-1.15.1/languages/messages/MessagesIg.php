<?php
/** Igbo (Igbo)
 *
 * See MessagesQqq.php for message documentation incl. usage of parameters
 * To improve a translation please visit http://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 */

$messages = array(
'navigation' => 'evu vo',

'search'         => 'Chozie ihe i dị cho',
'toolbox'        => 'Ngwa Oru',
'otherlanguages' => "Edemede nke n'olu ndị ọzọ",

# All link text and link target definitions of links into project namespace that get used by other message strings, with the exception of user group pages (see grouppage) and the disambiguation template definition (see disambiguations).
'mainpage'             => 'Page mbu',
'mainpage-description' => 'Page mbu',
'portal'               => 'Lounge',
'portal-url'           => 'Project:Lounge',

'youhavenewmessagesmulti' => 'Inwere eziohu na $1',

# Short words for each namespace, by default used in the namespace tab in monobook
'nstab-template' => 'Model',

# What links here
'whatlinkshere' => 'Ihe na bia nga',

);
