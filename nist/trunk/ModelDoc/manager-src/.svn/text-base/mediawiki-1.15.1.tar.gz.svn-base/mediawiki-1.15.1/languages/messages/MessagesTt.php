<?php
/** Tatar (Tatarça/Татарча)
 *
 * @ingroup Language
 * @file
 *
 * @comment Placeholder for Tatar. Falls back to Tatar in Latin script.
 */

$fallback = 'tt-latn';
