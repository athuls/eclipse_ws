# Gwendolyn van der Linden
# Copyright (c) 2011 SC Solutions, Inc.
# All rights reserved
# $Id: __init__.py,v 1.3 2011/05/11 16:55:39 glinden Exp $

## \package scshm SC Structural Health Monitoring package.
