# Gwendolyn van der Linden
# Copyright (c) 2009 SC Solutions, Inc.
# All rights reserved
# $Id: __init__.py,v 1.2 2010/09/03 01:20:38 glinden Exp $

## \package scshm.database Database implementation.
