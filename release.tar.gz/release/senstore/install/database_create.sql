DROP DATABASE IF EXISTS %(database)s;
CREATE DATABASE %(database)s;
